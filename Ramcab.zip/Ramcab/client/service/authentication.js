angular.module('myApp').service('AuthenticationService', Service);

function Service($http, $cookies, $sessionStorage) {
    var service = {};
    service.Login = Login;
    service.Logout = Logout;
//service.driverLogin = driverLogin;
//service.adminLogin = adminLogin;

    return service;

    function Login(user, callback) {
        $http.post('/login', user).then(function(response) {
          console.log(response.data);

                if (response.data.success && response.data.jwttoken) {
                    $sessionStorage.tokenDetails = {
                        token: response.data.jwttoken
                    };
                    $http.defaults.headers.common.Authorization = response.data.jwttoken;
                    var obj = {
                        currentUser: {
                            isLoggedIn: true,
                            userInfo: {
                                id: response.data.userDetail._id,
                                Emailaddress: response.data.userDetail.Emailaddress,
                                FirstName: response.data.userDetail.FirstName,
                                 LastName: response.data.userDetail.LastName,
                                Contactno: response.data.userDetail.Contactno,
                                Usertype: response.data.userDetail.Usertype


                            }
                        }

                    };
                      console.log(obj);
                    $cookies.putObject('authUser', obj);
                    console.log(obj);
                    callback(response);
                } else {
                    callback(response);
                }
            });
    }
    function Logout() {
        delete $sessionStorage.tokenDetails;
        $http.defaults.headers.common.Authorization = '';
        $cookies.remove('authUser');

    }

  /*function driverLogin(driver, callback) {
          $http.post('/driverlogin', driver).then(function(response) {
            console.log(response.data);
                 if (response.data.success && response.data.jwttoken) {
                     $sessionStorage.tokenDetails = {
                         token: response.data.jwttoken
                     };
                     $http.defaults.headers.common.Authorization = response.data.token;
                     var obj = {
                         currentdriver: {
                             isLoggedIn: true,
                             driverInfo: {
                                      id: response.data.driverdetail._id,
                                   FirstName: response.data.driverdetail.FirstName,
                                   LastName: response.data.driverdetail.LastName,
                                  Address: response.data.driverdetail.Address,
                                  Contactno: response.data.driverdetail.Contactno,
                                  Emailaddress:response.data.driverdetail.Emailaddress,
                                  Password:response.data.driverdetail.Password,
                                  Licenseno: response.data.driverdetail.Licenseno,
                                 Cabtype: response.data.driverdetail.Cabtype,
                                 Carno: response.data.driverdetail.Carno,
                                 Usertype: response.data.driverdetail.Usertype

                             }
                         }
                     };
                      $cookies.putObject('authdriver', obj);
                      callback(response);
                  } else {
                     callback(response);
                }
            });
     }
     function Logout() {
        delete $sessionStorage.tokenDetails;
        $http.defaults.headers.common.Authorization = '';
        $cookies.remove('authdriver');

     }
     function adminLogin(admin, callback) {
             $http.post('/adminlogin', admin).then(function(response) {
               console.log(response.data);
                    if (response.data.success && response.data.jwttoken) {
                        $sessionStorage.tokenDetails = {
                            token: response.data.jwttoken
                        };
                        $http.defaults.headers.common.Authorization = response.data.token;
                        var obj = {
                            currentadmin: {
                                isLoggedIn: true,
                                adminInfo: {
                                         id: response.data.admindetail._id,
                                      Name: response.data.admindetail.Name,
                                    Emailaddress:response.data.admindetail.Emailaddress,
                                     Password:response.data.admindetail.Password,
                                     Usertype: response.data.admindetail.Usertype

                                }
                            }
                        };
                         $cookies.putObject('authadmin', obj);
                         callback(response);
                     } else {
                        callback(response);
                   }
               });
        }
        function Logout() {
           delete $sessionStorage.tokenDetails;
           $http.defaults.headers.common.Authorization = '';
           $cookies.remove('authadmin');

        }*/

   }
