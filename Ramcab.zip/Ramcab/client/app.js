var app = angular.module('myApp',['ngRoute','ngCookies', 'ngStorage']);
app.config(function($routeProvider){
  $routeProvider.when('/',{
    templateUrl:'/views/main.html',
    controller:'maincontroller'
  }).when('/booking',{
    templateUrl:'/views/booking.html',
    controller:'bookingcontroller'
  }).when('/traiff',{
    templateUrl:'/views/traiff.html',
    controller:'traiffcontroller'
}).when('/driverdetail',{
  templateUrl:'/views/driverdetail.html',
  controller:'driverdetailcontroller'
}).when('/register',{
  templateUrl:'/views/register.html',
  controller:'registercontroller'
}).when('/adminregister',{
  templateUrl:'/views/adminregister.html',
  controller:'adminregistercontroller'
}).when('/login',{
  templateUrl:'/views/login.html',
  controller:'logincontroller'
})/*.when('/driverlogin',{
  templateUrl:'/views/driverlogin.html',
  controller:'driverlogincontroller'
}).when('/adminlogin',{
  templateUrl:'/views/adminlogin.html',
  controller:'adminlogincontroller'
})*/.when('/driver',{
  templateUrl:'/views/driver.html',
  controller:'drivercontroller'
}).when('/registersuccess',{
  templateUrl:'/views/registersucess.html',
  controller:'registersuccesscontroller'
}).when('/ridehistory',{
  templateUrl:'/views/ridehistory.html',
  controller:'ridehistorycontroller'
}).when('/unauthorized',{
  templateUrl:'/views/unauthorized.html'
});
});
/*app.run(function($rootScope, $http, $location, $sessionStorage, $cookies) {
    if ($sessionStorage.tokenDetails) {
        $http.defaults.headers.common.Authorization = $sessionStorage.tokenDetails.token;
    }


   $rootScope.$on('$locationChangeStart', function(event, next, current) {
        var publicPages = ['/', '/customerlogin', '/register'];
        var Adminpages = ['/','/booking','/adminlogin','/traiff','/driverdetail'];
        var CustomerPages = ['/','/booking','/customerlogin','/register','/ridehistory','/registersuccess'];
        var DriverPages = ['/','/driver','/driverlogin'];
        var restrictedPage;
        //var restrictedPage = publicPages.indexOf($location.path()) === -1;
var authUser = $cookies.getObject('authUser');
          if (authUser != undefined) {
              var loggedInUser = authUser.currentUser.userInfo;
              console.log(loggedInUser);
          }
          var authdriver = $cookies.getObject('authdriver');
                    if (authdriver != undefined) {
                        var loggedIndriver = authdriver.currentdriver.driverInfo;
                        console.log(loggedIndriver);
                    }
                    var authadmin = $cookies.getObject('authadmin');
                              if (authadmin != undefined) {
                                  var loggedInadmin = authadmin.currentadmin.adminInfo;
                                  console.log(loggedInadmin);
                              }

          if (restrictedPage && !$sessionStorage.tokenDetails && $location.path() != '') {
              $location.path('/adminlogin');
          } else {
              if (authadmin != undefined) {
                  if (authadmin.currentadmin.adminInfo.Usertype == 'Admin') {
                      var Admin = Adminpages.indexOf($location.path()) === -1;
                      if (Admin) {
                          $location.path('/unauthorized');
                      }
                  }
                }
              }
              if (restrictedPage && !$sessionStorage.tokenDetails && $location.path() != '') {
                  $location.path('/customerlogin');
              }else{
                if (authUser != undefined) {
                  if (authUser.currentUser.userInfo.Usertype == 'Customer') {
                      var Customer = CustomerPages.indexOf($location.path()) === -1;
                      if (Customer) {
                          $location.path('/unauthorized');
                      }
                  }
                }
}
if (restrictedPage && !$sessionStorage.tokenDetails && $location.path() != '') {
    $location.path('/driverlogin');
}else{
                if (authdriver != undefined) {
                  if (authdriver.currentdriver.driverInfo.Usertype == 'Driver') {
                      var Driver = DriverPages.indexOf($location.path()) === -1;
                      if (Driver) {
                          $location.path('/unauthorized');
                      }
                  }
              }
}
    });
});*/
app.run(function($rootScope, $http, $location, $sessionStorage, $cookies) {
    if ($sessionStorage.tokenDetails) {
        $http.defaults.headers.common.Authorization = $sessionStorage.tokenDetails.token;
    }


    $rootScope.$on('$locationChangeStart', function(event, next, current) {
        var publicPages = ['/', '/login', '/register'];
        var Adminpages = ['/','/booking','/login','/traiff','/driverdetail'];
        var CustomerPages = ['/','/booking','/login','/register','/ridehistory','/registersuccess'];
        var DriverPages = ['/','/driver','/login'];
var authUser = $cookies.getObject('authUser');
          if (authUser != undefined) {
              var loggedInUser = authUser.currentUser.userInfo;
              console.log(loggedInUser);
          }
          var restrictedPage = publicPages.indexOf($location.path()) === -1;
          if (restrictedPage && !$sessionStorage.tokenDetails && $location.path() != '') {
              $location.path('/login');
          } else {
              if (authUser != undefined) {
                  if (authUser.currentUser.userInfo.Usertype == 'Admin') {
                      var Admin = Adminpages.indexOf($location.path()) === -1;
                      if (Admin) {
                          $location.path('/unauthorized');
                      }
                  }
                  if (authUser.currentUser.userInfo.Usertype == 'Customer') {
                      var Customer = CustomerPages.indexOf($location.path()) === -1;
                      if (Customer) {
                          $location.path('/unauthorized');
                      }
                  }
                  if (authUser.currentUser.userInfo.Usertype == 'Driver') {
                      var Driver = DriverPages.indexOf($location.path()) === -1;
                      if (Driver) {
                          $location.path('/unauthorized');
                      }
                  }
              }
          }
    });
});
