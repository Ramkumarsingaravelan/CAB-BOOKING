angular.module('myApp').controller('registercontroller',function($scope,$http){
  $scope.RegisterUser = function() {

        $http.post('/signup', $scope.register).then(function(response) {
            alert('User Registration Successfull');


        });
    }
});
