angular.module('myApp').controller('footercontroller',function($scope,$http){
  });
