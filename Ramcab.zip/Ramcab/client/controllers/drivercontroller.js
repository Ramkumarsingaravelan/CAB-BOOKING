angular.module('myApp').controller('drivercontroller',function($scope,$http,$cookies){
var socket=io();
var customers=[];
var Name,contact,lat,long;
var dname,dcontact,dcarno,dcab,demail,dplocation,ddeslocation,carno,amount,did,amt;
var loggedInUser;
var authUser;
$scope.customer = {};


   authUser = $cookies.getObject('authUser');
        console.log(authUser);
        if (authUser != undefined) {
            loggedInUser = authUser.currentUser.userInfo;
            console.log(loggedInUser);
          }

  init();

function init(){
if (navigator.geolocation)
 {
 navigator.geolocation.getCurrentPosition(function (position)
  {
  var latlng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
  lat=position.coords.latitude;
  long=position.coords.longitude;
  var geocoder = new google.maps.Geocoder();
var infowindow = new google.maps.InfoWindow();

var mapOptions = {
zoom: 18,
center:latlng,
mapTypeId: google.maps.MapTypeId.ROADMAP
};

map = new google.maps.Map(document.getElementById("myMap"), mapOptions);

var icon = {
    url: "public/images/cartopview.png", // url
    scaledSize: new google.maps.Size(50, 50), // scaled size
    origin: new google.maps.Point(0,0), // origin
    anchor: new google.maps.Point(0, 0) // anchor
};
marker = new google.maps.Marker({
map: map,
position:latlng,
draggable: true,
icon:icon
});
geocoder.geocode({'latLng': latlng }, function(results, status) {
if (status == google.maps.GeocoderStatus.OK) {
if (results[0]) {
$('#latitude,#longitude').show();
$('#address').val(results[0].formatted_address);
$('#latitude').val(marker.getPosition().lat());
lat=document.getElementById("latitude").value;
// alert(lat);
$('#longitude').val(marker.getPosition().lng());
long=document.getElementById("longitude").value;
// alert(long);
infowindow.setContent(results[0].formatted_address);
infowindow.open(map, marker);

}
}

});

console.log(lat);

socket.emit('drivermessage',{
  latitude:lat,
  longitude:long,
  FirstName:dname,
  Contactno:dcontact,
  Carno:dcarno,
  cabtype:dcab,
  id:did,
  Emailaddress:demail




});

console.log(socket);
console.log("socket live");



google.maps.event.addListener(marker, 'dragend', function() {

geocoder.geocode({'latLng': marker.getPosition()}, function(results, status) {
if (status == google.maps.GeocoderStatus.OK) {
if (results[0]) {
$('#address').val(results[0].formatted_address);
$('#latitude').val(marker.getPosition().lat());
lat=document.getElementById("latitude").value;
$('#longitude').val(marker.getPosition().lng());
long=document.getElementById("longitude").value;

infowindow.setContent(results[0].formatted_address);
infowindow.open(map, marker);
}
}

});
});



var directionsService = new google.maps.DirectionsService();
  google.maps.event.addDomListener(window, 'load', function () {
      new google.maps.places.SearchBox(document.getElementById('ac1'));
      directionsDisplay = new google.maps.DirectionsRenderer({ 'draggable': true });
  });
});
}


        /*var authdriver = $cookies.getObject('authdriver');
                console.log(authdriver);
              if (authdriver != undefined) {
                  loggedIndriver = authdriver.currentdriver.driverInfo;
                  console.log(loggedIndriver);
                  did=authdriver.currentdriver.driverInfo.id;
                  dname=authdriver.currentdriver.driverInfo.FirstName;
                  dcontact=authdriver.currentdriver.driverInfo.Contactno;
                  dcarno=authdriver.currentdriver.driverInfo.Carno;
                  dcab=authdriver.currentdriver.driverInfo.Cabtype;
                  demail=authdriver.currentdriver.driverInfo.Emailaddress;
                  contact=authdriver.currentdriver.driverInfo.Contactno;
                  carno=authdriver.currentdriver.driverInfo.Carno;
                  console.log(did);
                }*/
                var authUser = $cookies.getObject('authUser');
                        console.log(authUser);
                      if (authUser != undefined) {
                          loggedIndriver = authUser.currentUser.userInfo;
                          console.log(loggedIndriver);
                          did=authUser.currentUser.userInfo.id;
                          dname=authUser.currentUser.userInfo.FirstName;
                          dcontact=authUser.currentUser.userInfo.Contactno;
                          dcarno=authUser.currentUser.userInfo.Carno;
                          dcab=authUser.currentUser.userInfo.Cabtype;
                          demail=authUser.currentUser.userInfo.Emailaddress;
                          contact=authUser.currentUser.userInfo.Contactno;
                          carno=authUser.currentUser.userInfo.Carno;
                          console.log(did);
                        }



            console.log("Driver.. "+did);
            socket.on(did,function(data){
              console.log("Booking arrived from");
              console.log(data);

            data.cust_name;
            console.log(data.cust_name);
            //$scope.customerName=data.cust_name;
            //console.log($scope.customerName);
                $('#customerName').html(data.cust_name);
                $('#customerNo').html(data.cust_contact);
                $('#customerPickup').html(data.cust_pickup);
                $('#customerDrop').html(data.cust_drop);
                $('#customerAmount').html(data.cust_amount);
$(document).ready(function(){
  $("#exampleModal").modal();
});
              });

          console.log("called");

          socket.on('customerdetail',function(data){
            console.log(data);
            /*customers.push(data);
            $scope.customer = {};
            for(var i = 0; i<customers.length; i++){
              console.log(customers[i]);
              $scope.customer = customers[i];
              console.log($scope.customer.id);
              $('#customerName').html($scope.customer.FirstName);
            }*/
          });

            socket.emit('selectedDriver',{
                Name:dname,
              //PickupLocation:dploction,
              //DestinationLocation:ddeslocation,
                contactno:contact,
                vechicleinfo:carno,
                Amount:amt

            });


}



});
