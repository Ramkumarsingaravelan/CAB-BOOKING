angular.module('myApp').controller('adminlogincontroller',function($scope,$http, AuthenticationService, $location,$rootScope){
  $scope.adminlogin = function() {
    AuthenticationService.adminLogin($scope.Admin,function(response){
      console.log(response);
     if (response.data.success === true) {
                      if(response.data.admindetail.Usertype=="Admin"){
                          $location.path('/booking');
                          $rootScope.$emit('CallLoginAdmin', {});
                      }

                      else{
                        $scope.success=response.data.success;
                        console.log(response.data.success);
                        $rootScope.$emit('CallLoginAdmin', {});
                      }
                    }
                  });

    }
  });
