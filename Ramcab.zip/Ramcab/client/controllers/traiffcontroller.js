angular.module('myApp').controller('traiffcontroller',function($scope,$http){

  var refreshType = function () {

      $http.get('/traiff').success(function (response) {

          console.log('Car READ IS SUCCESSFUL');
          $scope.typeslist = response;
          $scope.traiff = "";
          $scope.traiff = {};
          /*$('input.timepicker').timepicker({
            //$scope.booking.PickTime=timeText;

            //timeFormat: 'h:mm p',
            interval: 60,
            minTime: '10',
            //maxTime: '6:00pm',
            //defaultTime: '11',
            startTime: '10:00',
            dynamic:false,
            dropdown: true,
            scrollbar:true,
                change: function(time,text) {
                    // the input field
                    var element = $(this), text;
                    // get access to this Timepicker instance
                    var timepicker = element.timepicker();
                    text = timepicker.format(time);
                    element.siblings('span.help-line').text(text);
                    $scope.traiff.StartPeakTime=text;
                    console.log(text);
                }
            });
            $('input.timepicker1').timepicker({
              //$scope.booking.PickTime=timeText;

              //timeFormat: 'h:mm p',
              interval: 60,
              minTime: '10',
              //maxTime: '6:00pm',
              //defaultTime: '11',
              startTime: '10:00',
              dynamic:false,
              dropdown: true,
              scrollbar:true,
                  change: function(time,text1) {
                      // the input field
                      var element = $(this), text;
                      // get access to this Timepicker instance
                      var timepicker = element.timepicker();
                      text1 = timepicker.format(time);
                      element.siblings('span.help-line').text(text1);
                      $scope.traiff.EndPeakTime=text1;
                      console.log(text1);
                  }
              });*/

      });
  };

  refreshType();
  $scope.cartype=function(){

    $http.post('/addtraiff',$scope.traiff).then(function(response){
      console.log(response);
      console.log($scope.traiff);
        refreshType();

    });
  }

  $scope.removeType = function (id) {
        console.log(id);

      //confirm({text: 'Are you sure you want to delete?'})
        $http.delete('/traiff/' + id._id).then(function (response) {
            console.log(response);
            console.log('CAR IS DELETED SUCCESSFULLY');
           refreshType();
        });


    };
var TID;
    $scope.editType = function (id) {
      TID=id._id;
         $http.get('/traiff/' + id._id).then(function (response) {
           console.log(response);
            $scope.Edittraiff = {
              CarType:response.data[0].CarType,
              NormalHourRate:response.data[0].NormalHourRate,
              PeakHourRate:response.data[0].PeakHourRate,
              StartPeakTime:response.data[0].StartPeakTime,
              EndPeakTime:response.data[0].EndPeakTime,

            }
        });
    };

  $scope.Savechanges = function () {
        console.log("REACHED UPDATE");
        console.log($scope.traiff._id);
        $http.put('/traiff/'+ TID, $scope.Edittraiff).then(function (response) {
            console.log(response);
            refreshType();
        });
    };



});
