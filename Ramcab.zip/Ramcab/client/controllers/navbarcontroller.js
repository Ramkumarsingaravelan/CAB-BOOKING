angular.module('myApp').controller('navbarcontroller',function($scope,$http,$cookies,$location, AuthenticationService,$rootScope){
var nav = this;
nav.FirstName = '';
nav.UserType = '';
nav.isLoggedIn = true;
initController();
function initController(){
	var authUser = $cookies.getObject('authUser');
	if (authUser != undefined) {
		var loggedInUser =  authUser.currentUser.userInfo;
		var isLoggedIn = authUser.currentUser.isLoggedIn;

		if(isLoggedIn) {
			nav.isLoggedIn = isLoggedIn;
			nav.FirstName = loggedInUser.FirstName;
			nav.UserType =  loggedInUser.Usertype;

		}
	}

	else {
		nav.isLoggedIn = false;
	}
}
/*init();
function init(){
	var authdriver = $cookies.getObject('authdriver');
	if (authdriver != undefined) {
		var loggedInUser =  authdriver.currentdriver.driverInfo;
		var isLoggedIn = authdriver.currentdriver.isLoggedIn;

		if(isLoggedIn) {
			nav.isLoggedIn = isLoggedIn;
			nav.FirstName = loggedInUser.FirstName;
			nav.UserType =  loggedInUser.Usertype;

		}
	}

	else {
		nav.isLoggedIn = false;
	}
}
initAdmin();
function initAdmin(){
	var authadmin = $cookies.getObject('authadmin');
	if (authadmin != undefined) {
		var loggedInUser =  authadmin.currentadmin.adminInfo;
		var isLoggedIn = authadmin.currentadmin.isLoggedIn;

		if(isLoggedIn) {
			nav.isLoggedIn = isLoggedIn;
			nav.FirstName = loggedInUser.Name;
			nav.UserType =  loggedInUser.Usertype;

		}
	}

	else {
		nav.isLoggedIn = false;
	}
}*/


$scope.customerlogin = function(){
	initController();

}
/*$scope.driverlogin = function(){
	init();

}
$scope.adminlogin = function(){
	initAdmin();
}*/
$rootScope.$on('CallLoginUser', function(){
	$scope.customerlogin();

});
$scope.LogoutUser = function(){
	AuthenticationService.Logout();
	nav.isLoggedIn = false;
	$location.path('/');
}

$rootScope.$on('CallLoginDriver', function(){
	$scope.driverlogin();

});
$scope.LogoutUser = function(){
	AuthenticationService.Logout();
	nav.isLoggedIn = false;
	$location.path('/');
}
$rootScope.$on('CallLoginAdmin', function(){
	$scope.adminlogin();

});
$scope.LogoutUser = function(){
	AuthenticationService.Logout();
	nav.isLoggedIn = false;
	$location.path('/');
}

});
