angular.module('myApp').controller('driverdetailcontroller',function($scope,$http){
  var detailType = function () {
      $http.get('/driverdetail').success(function (response) {
          console.log('Driver Detail Is Successfully');
          $scope.addingdetail = response;
          $scope.driverdetail = "";
      });
  };

  detailType();
  $scope.drivertype=function(){
    $http.post('/adddriverdetail',$scope.driverdetail).then(function(response){
      console.log(response);
      alert("Driver Registration Successfull")
      //$scope.driverdetail.UserType="Driver";
      $http.post('/driversignup', $scope.driverdetail).then(function(response) {
console.log(response);
        detailType();
    });
  });
  };
  $scope.delete = function (id) {
        console.log(id);
        $http.delete('/driverdetail/' + id._id).then(function (response) {
            console.log(response);
            console.log('DRIVER DETAIL IS DELETED SUCCESSFULLY');
           detailType();
        });
    };
    var DID;
        $scope.edit = function (id) {
          DID=id._id;
             $http.get('/driverdetail/' + id._id).then(function (response) {
               console.log(response);
                $scope.Editdriverdetail = {
                  FirstName:response.data[0].FirstName,
                  LastName:response.data[0].LastName,
                  Contactno:response.data[0].Contactno,
                  Emailaddress:response.data[0].Emailaddress,
                  Password:response.data[0].Password,
                  Licenseno:response.data[0].Licenseno,
                  Cabtype:response.data[0].Cabtype,
                  Carno:response.data[0].Carno,

                }
            });
        };

      $scope.Savechanges = function () {
            console.log("REACHED UPDATE");
            console.log($scope.driverdetail._id);
            $http.put('/driverdetail/'+ DID, $scope.Editdriverdetail).then(function (response) {
                console.log(response);
                detailType();
            });
        };
});
