angular.module('myApp').controller('driverlogincontroller',function($scope,$http, AuthenticationService, $location,$rootScope){
  $scope.driverlogin = function() {
    AuthenticationService.driverLogin($scope.Driver,function(response){
      console.log(response);
     if (response.data.success === true) {
                      if(response.data.driverdetail.Usertype=="Driver"){
                          $location.path('/driver');
                          $rootScope.$emit('CallLoginDriver', {});
                      }

                      else{
                        $scope.success=response.data.success;
                        console.log(response.data.success);
                        $rootScope.$emit('CallLoginDriver', {});
                      }
                    }
                  });

    }
  });
