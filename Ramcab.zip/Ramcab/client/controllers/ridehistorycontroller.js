angular.module('myApp').controller('ridehistorycontroller',function($scope,$http,$rootScope, $sessionStorage, $cookies){
var loggedInUser;
$scope.Email={};
var drivers = [];
myRide();
function myRide(Email)
{
  authUser = $cookies.getObject('authUser');
          console.log(authUser);
          if (authUser != undefined) {
              loggedInUser = authUser.currentUser.userInfo;
              console.log(loggedInUser);

              //console.log(userid);
              if(loggedInUser.Usertype == 'Customer'){
                  $scope.Email = loggedInUser.Emailaddress;
                  console.log($scope.Email);
                    $http.get('/bookcab/').then(function(response){
console.log(response);
//$http.get('/bookcab').then(function(response){
///  console.log(response);
$scope.Rides=response.data;
  console.log($scope.Rides);
                    });
//});
                    /*$http.get('/bookcab').then(function (response) {
                      console.log(response);
                    $scope.Rides=response.data;
                      console.log($scope.Rides);

                    });
                }
            }
            else {
              $scope.Email = loggedInUser.Emailaddress;

            }*/
}
}

}
  });
