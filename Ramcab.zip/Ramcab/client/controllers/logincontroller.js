angular.module('myApp').controller('logincontroller',function($scope,$http, AuthenticationService, $location,$rootScope){
  $scope.login = function() {
AuthenticationService.Login($scope.User,function(response){
  console.log(response);
 if (response.data.success === true) {
                  if(response.data.userDetail.Usertype=="Customer"){
                      $location.path('/booking');
                      $rootScope.$emit('CallLoginUser', {});
                  }
                   if (response.data.userDetail.Usertype=="Admin") {
                    $location.path('/');
                    $rootScope.$emit('CallLoginUser', {});
                  }
                  if (response.data.userDetail.Usertype=="Driver") {
                   $location.path('/driver');
                   $rootScope.$emit('CallLoginUser', {});
                 }
                  else{
                    $scope.success=response.data.success;
                    console.log(response.data.success);
                    $rootScope.$emit('CallLoginUser', {});
                  }
                }
              });
        }
});
