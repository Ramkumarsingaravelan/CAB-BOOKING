    angular.module('myApp').controller('bookingcontroller',function($scope,$http,$cookies){

      var distance,duration,i,source,destination;
      var newdistance=0;
      var authUser;
      var drivers = [];
      var socket=io();
      var lat;
      var long;
      var directionsDisplay;
      $scope.selectedDriver = {};
      var userid;
      var Name;
      var contact;
      var amt;

      //$scope.driverName = "";
      //$scope.driverPhone = "";

      //$scope.carName = {
        //    "id": "1",
            //"value": "Mini"

        //  };
      //$scope.carOption = "";

      $scope.later=false;

    $scope.initmap=function(){
      if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(showPosition);
        } else {
            x.innerHTML = "Geolocation is not supported by this browser.";
        }

    }
    function showPosition(position) {

      var latlng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
     lat=position.coords.latitude;
      long=position.coords.longitude;
           var geocoder = new google.maps.Geocoder();
           var infowindow = new google.maps.InfoWindow();

              var mapOptions = new google.maps.Map(document.getElementById('map'), {
                zoom: 16,
                center: latlng,
                mapTypeId: google.maps.MapTypeId.ROADMAP
              });
              map = new google.maps.Map(document.getElementById("map"), mapOptions);
               marker = new google.maps.Marker({
                position: latlng,
                  map:map,
                draggable: true
              });


              geocoder.geocode({'latLng': latlng }, function(results, status) {
              if (status == google.maps.GeocoderStatus.OK) {
              if (results[0]) {
                $('#latitude,#longitude').show();
                if (results.length > 1){
                  $('#address').val(results[1].formatted_address);
                  $scope.booking.PickupLocation = results[1].formatted_address;
                  infowindow.setContent(results[1].formatted_address);
                }else{
                  $('#address').val(results[0].formatted_address);
                  $scope.booking.PickupLocation = results[0].formatted_address;
                  infowindow.setContent(results[0].formatted_address);
                }



              $('#latitude').val(marker.getPosition().lat());
              lat=document.getElementById("latitude").value;

              $('#longitude').val(marker.getPosition().lng());
              long=document.getElementById("longitude").value;


              infowindow.open(map, marker);

              }
              }
            authUser = $cookies.getObject('authUser');
                    console.log(authUser);
                    if (authUser != undefined) {
                        loggedInUser = authUser.currentUser.userInfo;
                        console.log(loggedInUser);
                        userid=authUser.currentUser.userInfo.id;
                    Name=authUser.currentUser.userInfo.FirstName;
                    contact=authUser.currentUser.userInfo.Contactno;
                        console.log(userid);
                      }


              socket.emit('customerdetail', {
                id:userid,
              userlatitude:lat,
              userlongitude:long,
              FirstName:Name,
              Contactno:contact

            });
              });


    google.maps.event.addListener(marker, 'dragend', function() {

    geocoder.geocode({'latLng': marker.getPosition()}, function(results, status) {
    if (status == google.maps.GeocoderStatus.OK) {
    if (results[0]) {
    $('#address').val(results[0].formatted_address);
    $('#latitude').val(marker.getPosition().lat());
    lat=document.getElementById("latitude").value;
    $('#longitude').val(marker.getPosition().lng());
    long=document.getElementById("longitude").value;

    infowindow.setContent(results[0].formatted_address);
    infowindow.open(map, marker);

    }
    }
    });
    });

    init();

        function init() {

            var acInputs = document.getElementsByClassName("autocomplete");
//types: ['(regions)']
//console.log(types);
            for (var i = 0; i < acInputs.length; i++) {

                var autocomplete = new google.maps.places.Autocomplete(acInputs[i]);
                autocomplete.addListener('place_changed',function(){
                  console.log("place picked");
                });

                autocomplete.inputId = acInputs[i].id;

            }
        }
}


        var directionsService = new google.maps.DirectionsService();
        google.maps.event.addDomListener(window, 'load', function () {
            new google.maps.places.SearchBox(document.getElementById('address'));
            new google.maps.places.SearchBox(document.getElementById('ac1'));
            directionsDisplay = new google.maps.DirectionsRenderer({ 'draggable': true });
        });





    $scope.estimateValue=function(){
    $scope.estimate=true;

         source=document.getElementById("address").value;
        destination=document.getElementById("ac1").value;

        function GetRoute() {
          directionsDisplay = new google.maps.DirectionsRenderer({ 'draggable': true });

          map = new google.maps.Map(document.getElementById("map"));
            directionsDisplay.setMap(map);



            source=document.getElementById("address").value;

           destination=document.getElementById("ac1").value;


            var request = {
                origin: source.replace(/ /g,'+').replace('+',''),
                destination: destination.replace(/ /g,'+').replace('+',''),
                travelMode: google.maps.TravelMode.DRIVING
            };
            console.log(request);
            directionsService.route(request, function (response, status) {
                if (status == google.maps.DirectionsStatus.OK) {
                    directionsDisplay.setDirections(response);
                }
            });
    }

    GetRoute();
    source=document.getElementById("address").value;
    destination=document.getElementById("ac1").value;
    var service = new google.maps.DistanceMatrixService();

           service.getDistanceMatrix({
               origins: [source.replace(/ /g,'+').replace('+','')],
               destinations: [destination.replace(/ /g,'+').replace('+','')],
               travelMode: google.maps.TravelMode.DRIVING,
               unitSystem: google.maps.UnitSystem.METRIC,
               avoidHighways: false,
               avoidTolls: false
           }, function (response, status) {
             console.log(status);
             console.log(response);
               if (status == google.maps.DistanceMatrixStatus.OK && response.rows[0].elements[0].status != "ZERO_RESULTS") {
                     distance = response.rows[0].elements[0].distance.text;
                     duration = response.rows[0].elements[0].duration.text;

                    document.getElementById("totalDist").innerHTML=distance;
                    document.getElementById("totalTime").innerHTML=duration;
                    console.log(distance);
                    $scope.booking.Distance=distance;
                    console.log($scope.booking.Distance);
                    $scope.booking.Duration=duration;
                    console.log($scope.booking.Duration);
                    console.log($scope.booking.carOption);
                    $http.get('/traiff/cabtype/'+$scope.booking.carOption).then(response =>{
                      console.log(response);
                      if (response.data){
                        $scope.traiff = null;
                        var carObj = response.data;
                        if ($scope.booking.carOption == carObj.CarType){
                          //console.log(carObj);
                          $scope.traiff=carObj;
                          console.log($scope.traiff.NormalHourRate);

                           amt=parseFloat(distance)*$scope.traiff.NormalHourRate;
                          document.getElementById("totalamt").innerHTML=amt;
                          console.log(amt);
                          $scope.booking.Amount=amt;
                          console.log($scope.booking.Amount);
                        }else{
                          alert("Pick the cab first!!!");
                        }
                      }else {
                        alert("Selected cab type does not exists");
                      }
                    });

                }
                else
                  {
                    console.log("error"+status);
                  }

    });

    }
    $scope.ridelater=function (){
    $scope.later=true;

  $("#datepicker").datepicker({

minDate:new Date(2018,4,5)
    /*onSelect: function(dateText, inst) {
      console.log(dateText);

      //minDate:new Date(2018,3,22)

        $scope.booking.PickupDate = dateText();


  }*/

  });



//$('.timepicker').timepicker();
$('input.timepicker').timepicker({
  //$scope.booking.PickTime=timeText;

  //timeFormat: 'h:mm p',
  interval: 30,
  minTime: '0',
  maxTime: '6:00pm',
  //defaultTime: '11',
  startTime: '10:00',
  dynamic:false,
  dropdown: true,
  scrollbar:true,
      change: function(time,text) {
          // the input field
          var element = $(this), text;
          // get access to this Timepicker instance
          var timepicker = element.timepicker();
          text = timepicker.format(time);
          element.siblings('span.help-line').text(text);
          $scope.booking.PickTime=text;
          console.log(text);
      }
  });


}



    var bookingType = function () {
    $http.get('/bookcab').then(function (response) {
        console.log(response);
        //$scope.booking.carOption = response;
        //console.log($scope.carOption);
        $scope.booking = {};

    });
    };
    bookingType();
    $scope.save=function()
    {
      console.log($scope.booking);

      $http.post('/addbook',$scope.booking).then(response =>{
        console.log(response);
        bookingType();
        alert("Advance Ride saved Successfully");
    });

    }

    $scope.rideNow=function(){
      if(drivers.length==0)
      {
        alert("No Cab avaliable at this Moment");
        $("#exampleModal").modal({backdrop: 'static', keyboard: false});
      }

else {



      console.log($scope.booking);
      $http.post('/addbook',$scope.booking).then(response =>{
        console.log(response);
        bookingType();
        //alert("Ride saved Successfully");
        console.log($scope.selectedDriver.id);
        socket.emit("bookingConfirmToDriver",{cust_id:userid,cust_name:Name,cust_contact:contact,cust_amount:amt,cust_pickup:source,cust_drop:destination,driver_id:$scope.selectedDriver.id});
$scope.amount=amt;
console.log($scope.amount);
        $('#pickuplocation').html(source);

        $('#destinationlocation').html(destination);


    });

    /*  source=document.getElementById("address").value;
     destination=document.getElementById("ac1").value;

     function GetRoute() {
directionsDisplay = new google.maps.DirectionsRenderer({ 'draggable': true });
       map = new google.maps.Map(document.getElementById("map"));
         directionsDisplay.setMap(map);



         source=document.getElementById("address").value;
        destination=document.getElementById("ac1").value;


         var request = {
             origin: source,
             destination: destination,
             travelMode: google.maps.TravelMode.DRIVING
         };
         directionsService.route(request, function (response, status) {
             if (status == google.maps.DirectionsStatus.OK) {
                 directionsDisplay.setDirections(response);
             }
         });
    }
    GetRoute();

    var service = new google.maps.DistanceMatrixService();
        service.getDistanceMatrix({
            origins: [source],
            destinations: [destination],
            travelMode: google.maps.TravelMode.DRIVING,
            unitSystem: google.maps.UnitSystem.METRIC,
            avoidHighways: false,
            avoidTolls: false
        }, function (response, status) {
            if (status == google.maps.DistanceMatrixStatus.OK && response.rows[0].elements[0].status != "ZERO_RESULTS") {
                 distance = response.rows[0].elements[0].distance.text;
                 duration = response.rows[0].elements[0].duration.text;

                 document.getElementById("totalDist").innerHTML=distance;
                 document.getElementById("totalTime").innerHTML=duration;
                 console.log(distance);
                 console.log($scope.booking.carOption);
                 $http.get('/traiff/cabtype/'+$scope.booking.carOption).then(response =>{
                   console.log(response);
                   if (response.data){
                     $scope.traiff = null;
                     var carObj = response.data;
                     if ($scope.booking.carOption == carObj.CarType){
                       //console.log(carObj);
                       $scope.traiff=carObj;
                       console.log($scope.traiff.NormalHourRate);

                        amt=parseFloat(distance)*$scope.traiff.NormalHourRate;
                       document.getElementById("totalamt").innerHTML=amt;
                       console.log(amt);

                     }else{
                       alert("Pick the cab first!!!");
                     }
                   }else {
                     alert("Selected cab type does not exists");
                   }
                 });

             }
             else
               {
                 console.log("error"+status);
               }*/
               var distanceObj;
               $scope.selectedDriver = {};
               for(var i = 0; i<drivers.length; i++){
                 console.log(drivers[i]);
                 var localdistance = getDistanceFromLatLonInKm(lat,long,drivers[i].latitude,drivers[i].longitude);
                 if (!distanceObj){
                    distanceObj = localdistance;
                    $scope.selectedDriver = drivers[i];
                 }else if (localdistance < distanceObj){
                    distanceObj = localdistance;
                    $scope.selectedDriver = drivers[i];
                 }

//$scope.selectedDriver.FirstName=Dirvername;
//console.log(Dirvername);



               }

               console.log("Near distance is: "+distanceObj);
               console.log("Selected Drive is below");
               console.log($scope.selectedDriver);

              //


    console.log("deg called");

    //});
  }
}
    function getDistanceFromLatLonInKm(userlatitude,userlongitude,latitude,longitude) {
     // console.log(userlatitude);
      var R = 6371;
       // Radius of the earth in km
      var dLat = deg2rad(latitude-userlatitude);
        //console.log(dLat);// deg2rad below
      var dLon = deg2rad(longitude-userlongitude);
      var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
        Math.cos(deg2rad(userlatitude)) * Math.cos(deg2rad(latitude)) *
        Math.sin(dLon/2) * Math.sin(dLon/2);
      var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
      var d = R * c;
      console.log("Distance is: "+d);

      return d;

    }
    console.log("dist called");
    //deg2rad(deg);
    function deg2rad(deg) {
      return deg * (Math.PI/180)
    }


    console.log("on socket called");
    socket.on('drivermessage',function(data){
      //console.log(data);
      var latlng = new google.maps.LatLng(data.latitude, data.longitude);
      console.log(latlng);
      var icon = {
          url: "public/images/cartopview.png", // url
          scaledSize: new google.maps.Size(50, 50), // scaled size
          origin: new google.maps.Point(0,0), // origin
          anchor: new google.maps.Point(0, 0) // anchor
      };
      marker = new google.maps.Marker({
      map: map,
      position:latlng,
      draggable: false,
      icon:icon
      });
      console.log("on connect");
      console.log(data);
      drivers.push(data);
    });

    console.log(socket);
    console.log("socket live in booking");

    socket.on('selectedDriver',function(data){

    console.log(data);
    console.log("driver on");
  });
  socket.on('customerdetail',function(data){
    console.log("customer connected");
  });



    });
