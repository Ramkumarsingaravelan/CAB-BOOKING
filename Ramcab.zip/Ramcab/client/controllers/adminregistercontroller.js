angular.module('myApp').controller('adminregistercontroller',function($scope,$http){
  $scope.RegisterAdmin = function() {

        $http.post('/adminsignup', $scope.admindetail).then(function(response) {
          console.log(response);
            //alert('Admiadmindetail Registration Successfull');


        });
    }
});
