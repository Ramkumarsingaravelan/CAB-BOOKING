/*var app = angular.module('myApp', []);

app.directive('timepicki', [

  function() {
    var link;
    link = function(scope, element, attr, ngmodel) {
      element.timepicki();
    };

    return {
      restrict: 'A',
      link: link,
      require: 'ngmodel'
    };
  }
])
app.controller('ctrl', function($scope) {
  $scope.row1 = "00:00"
  $scope.dup_row1 = "hello"

  $scope.submit=function(){
    console.log($scope.dup_row1);
  }
});*/
