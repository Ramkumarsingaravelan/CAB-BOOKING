angualr.module('myApp').directive('footer',()=>({
  templateUrl:'views/footer.html',
  controller:'footercontroller',
  restrict:'E'
}))
