angular.module('myApp').directive('navbar',()=>({
  templateUrl:'/views/navbar.html',
  restrict:'E',
  controller:'navbarcontroller',
  controllerAs: 'nav'
}));
