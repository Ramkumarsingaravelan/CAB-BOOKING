var mongoose = require('mongoose');
var bcrypt = require('bcrypt-nodejs');
var driverdetailmodelsSchema = mongoose.Schema({

     FirstName:String,
     LastName:String,
     Address:String,
     Contactno:Number,
     Emailaddress:String,
     Password:String,
     Licenseno:String,
     Cabtype:String,
     Carno:String,
     Usertype:String
    });

    
module.exports = mongoose.model('driverdetailmodels', driverdetailmodelsSchema);
