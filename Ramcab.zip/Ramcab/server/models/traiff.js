var mongoose = require('mongoose');
var cabtypeSchema = mongoose.Schema({

     CarType:String,
     NormalHourRate:String,
     PeakHourRate:String,
     StartPeakTime:String,
     EndPeakTime:String


});

module.exports = mongoose.model('cabtype', cabtypeSchema);
