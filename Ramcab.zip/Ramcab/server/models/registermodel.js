var mongoose = require('mongoose');
var bcrypt = require('bcrypt-nodejs');
var registermodelSchema = mongoose.Schema({

     FirstName:String,
     LastName:String,
     Contactno:Number,
     Emailaddress:String,
     Password:String,
     Usertype:String

    });



module.exports = mongoose.model('registermodel', registermodelSchema);
