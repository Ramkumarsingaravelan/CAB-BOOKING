var mongoose = require('mongoose');
var BookingSchema = mongoose.Schema({
    BookingId:String,
    PickupLocation: String,
    DestinationLocation: String,
    carOption: String,
    PickupDate: String,
    PickTime: String,
    Distance:String,
    Duration:String,
    Dname:String,
    Amount:String

});

module.exports = mongoose.model('Bookingmodel', BookingSchema);
