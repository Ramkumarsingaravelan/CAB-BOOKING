var mongoose = require('mongoose');
var bcrypt = require('bcrypt-nodejs');
var adminmodelSchema = mongoose.Schema({

     FirstName:String,
     Emailaddress:String,
     Password:String,
     Usertype:String
    });
module.exports = mongoose.model('adminmodel', adminmodelSchema);
