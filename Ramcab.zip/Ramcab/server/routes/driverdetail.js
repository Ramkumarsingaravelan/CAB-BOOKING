var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var driverdetail = require('../models/driverdetailmodels');
var bcrypt=require('bcrypt-nodejs');

router.post('/adddriverdetail', function(req, res) {
    var newdriver = new driverdetail();
   newdriver.FirstName = req.body.FirstName;
   newdriver.LastName = req.body.LastName;
   newdriver.Address = req.body.Address;
   newdriver.Contactno = req.body.Contactno;
   newdriver.Emailaddress = req.body.Emailaddress;
   newdriver.Password = bcrypt.hashSync(req.body.Password);
   newdriver.Licenseno = req.body.Licenseno;
   newdriver.Cabtype = req.body.Cabtype;
   newdriver.Carno = req.body.Carno;
   newdriver.Usertype = 'Driver';
    newdriver.save(function(err,doc) {
        if (err) {
          console.log(err);
            throw err;
          }else
            res.json({
                success:true,
                message:'Record Saved'
          });
        });
      });
      router.get('/driverdetail', function(req, res) {
    driverdetail.find({}, function(err, docs) {
        res.json(docs);
    });
});
router.get('/driverdetail/:id', function(req, res) {
    driverdetail.find({
        '_id': req.params.id
    }, function(err, docs) {
        res.json(docs);
    });
});
router.delete('/driverdetail/:id', function(req, res) {
    driverdetail.remove({
        _id: req.params.id
    }, function(err, docs) {
        console.log('Removed Successfully');
        res.json(docs);
    });
});
router.put('/driverdetail/:id', function(req, res) {
  driverdetail.findOneAndUpdate({
    _id: req.params.id
  },{
    FirstName:req.body.FirstName,
    LastName:req.body.LastName,
    Contactno:req.body.Contactno,
    Emailaddress:req.body.Emailaddress,
    Password:bcrypt.hashSync(req.body.Password),
    Licenseno:req.body.Licenseno,
    Cabtype:req.body.Cabtype,
    Carno:req.body.Carno
  },function(err,docs){
    if (err)
    {
      throw err;
    }else{
      res.json({
        success:true,
        message:'Record Updated'
    });
    }
  });
});



module.exports = router;
