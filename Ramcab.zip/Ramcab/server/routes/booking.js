var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
var booking = require('../models/bookingmodel.js');


router.post('/addbook', function(req, res) {
  var newBook = new booking();
  newBook.BookingId = req.body.BookingId;
  newBook.PickupLocation = req.body.PickupLocation;
  newBook.DestinationLocation = req.body.DestinationLocation;
  newBook.carOption = req.body.carOption;
  newBook.PickupDate = req.body.PickupDate;
  newBook.PickTime = req.body.PickTime;
  newBook.Distance = req.body.Distance;
  newBook.Duration = req.body.Duration;
  newBook.Dname = req.body.Dname;
  newBook.Amount = req.body.Amount;
  newBook.save(function(err,doc) {
    if (err) {
      console.log(err);
      throw err;
    }else
    res.json({
      success:true,
      message:'Record Saved'
    });
  });
});
router.get('/bookcab', function(req, res) {
  booking.find({}, function(err, docs) {
    res.json(docs);
  });
});
router.get('/bookcab/:id', function(req, res) {
  console.log(req.params.id);
  booking.find({'_id': req.params.id}, function(err, docs) {
    res.json(docs);
  });
});
/*router.get('/bookcab:id', function(req, res) {
  console.log("book id below");
    console.log(req.params);
    booking.findOne({
      '_id': req.params.id
     }, function(err, docs) {
        res.json(docs);

    });
});*/






module.exports = router;
