var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var User = require('../models/registermodel');
var bcrypt=require('bcrypt-nodejs');
var jwt=require('jsonwebtoken');

router.post('/login',function(req,res){
  User.findOne({Emailaddress:req.body.Emailaddress},function(err,user){
    if (err){
      throw err;
    } else if(!user){
      res.json({success:false,message:'Sorry ! Wrong Emailaddress'});
      console.log('Emailaddress Not Found');
    } else if(!bcrypt.compareSync(req.body.Password, user.Password)){
      res.json({success: false, message: 'Sorry ! Wrong Password'});
      console.log('Password Incorrect ');
    }else if (user) {
        var token=jwt.sign(user.toObject(),'thisismysecret',{
          expiresIn: 1400
        });
        res.json({
                success: true,
                jwttoken: token,
                isLoggedIn: true,
                userDetail: user
            });
        console.log(token);
        console.log('Toke Created');

    }
  });
});

router.post('/signup', function(req, res) {
    var newuser = new User();
    newuser.FirstName = req.body.FirstName;
    newuser.LastName = req.body.LastName;
    newuser.Contactno = req.body.Contactno;
    newuser.Emailaddress = req.body.Emailaddress;
    newuser.Password = bcrypt.hashSync(req.body.Password);
    newuser.Usertype = 'Customer';

    newuser.save(function(err,doc) {
        if (err) {
          console.log(err);
            throw err;
          }else{
            res.json({
                success:true,
                message:'Record Saved'
          });
          }
        });
      });
    /*  router.post('/login',function(req,res){
        User.findOne({Emailaddress:req.body.Emailaddress},function(err,driver){
          if(err){
            throw err;
          } else if(!driver){
            res.json({success:false,message:'Sorry ! Wrong Emailaddress'});
            console.log('Emailaddress Not Found');
          } else if(!bcrypt.compareSync(req.body.Password, driver.Password)){
            res.json({success: false, message: 'Sorry ! Wrong Password'});
            console.log('Password Incorrect ');
          }else if(driver) {
              var token=jwt.sign(driver.toObject(),'thisismysecret',{
                expiresIn: 1400
              });
              res.json({
                      success: true,
                      jwttoken: token,
                      isLoggedIn: true,
                      userDetail: driver
                  });
              console.log(token);
              console.log('Toke Created');

          }
        });
      });*/
      router.post('/driversignup', function(req, res) {
          var newDriver = new User();
         newDriver.FirstName = req.body.FirstName;
         newDriver.LastName = req.body.LastName;
         newDriver.Address = req.body.Address;
         newDriver.Contactno = req.body.Contactno;
         newDriver.Emailaddress = req.body.Emailaddress;
         newDriver.Password = bcrypt.hashSync(req.body.Password);
         newDriver.Licenseno = req.body.Licenseno;
         newDriver.Cabtype = req.body.Cabtype;
         newDriver.Carno = req.body.Carno;
         newDriver.Usertype = 'Driver';
          newDriver.save(function(err,doc) {
              if (err) {
      console.log(err);
                throw err;
                //  res.json(err);
              } else {
                  res.json({
                      success: true,
                      message:'Record Saved'
                  });
                  console.log('Signup API Called');
              }
          });
      });

      /*router.post('/login',function(req,res){
        User.findOne({Emailaddress:req.body.Emailaddress},function(err,admin){
          if(err){
            throw err;
          } else if(!admin){
            res.json({success:false,message:'Sorry ! Wrong Emailaddress'});
            console.log('Emailaddress Not Found');
          } else if(!bcrypt.compareSync(req.body.Password, admin.Password)){
            res.json({success: false, message: 'Sorry ! Wrong Password'});
            console.log('Password Incorrect ');
          }else if(admin) {
              var token=jwt.sign(admin.toObject(),'thisismysecret',{
                expiresIn: 1400
              });
              res.json({
                      success: true,
                      jwttoken: token,
                      isLoggedIn: true,
                      userDetail: admin
                  });
              console.log(token);
              console.log('Toke Created');

          }
        });
      });*/
      router.post('/adminsignup', function(req, res) {
          var newAdmin = new User();
         newAdmin.FirstName = req.body.FirstName;
         newAdmin.Emailaddress = req.body.Emailaddress;
         newAdmin.Password = bcrypt.hashSync(req.body.Password);
         newAdmin.Usertype = 'Admin';
          newAdmin.save(function(err,doc) {
              if (err) {
      console.log(err);
                throw err;
                //  res.json(err);
              } else {
                  res.json({
                      success: true,
                      message:'Record Saved'
                  });
                  console.log('Signup API Called');
              }
          });
      });
module.exports = router;
