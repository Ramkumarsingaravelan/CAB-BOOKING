var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var cabtype = require('../models/traiff');



router.post('/addtraiff', function(req, res) {
    var newCab = new cabtype();
   newCab.CarType = req.body.CarType;
   newCab.NormalHourRate = req.body.NormalHourRate;
   newCab.PeakHourRate = req.body.PeakHourRate;
   newCab.StartPeakTime = req.body.StartPeakTime;
   newCab.EndPeakTime = req.body.EndPeakTime;
    newCab.save(function(err,doc) {
        if (err) {
          console.log(err);
            throw err;
          }else
            res.json({
                success:true,
                message:'Record Saved'
          });
        });
      });
      router.get('/traiff', function(req, res) {
    cabtype.find({}, function(err, docs) {
        res.json(docs);
    });
});

router.get('/traiff/:id', function(req, res) {
    cabtype.find({
        '_id': req.params.id
    }, function(err, docs) {
        res.json(docs);
    });
});


router.get('/traiff/cabtype/:cabtype', function(req, res) {
    console.log(req.params);
    cabtype.findOne({
        'CarType': req.params.cabtype
    }, function(err, docs) {
        res.json(docs);
    });
});

router.delete('/traiff/:id', function(req, res) {
    cabtype.remove({
        _id: req.params.id
    }, function(err, docs) {
        console.log('Removed Successfully');
        res.json(docs);
    });
});

router.put('/traiff/:id', function(req, res) {
  cabtype.findOneAndUpdate({
    _id: req.params.id
  },{
    CarType:req.body.CarType,
    NormalHourRate:req.body.NormalHourRate,
    PeakHourRate:req.body.PeakHourRate,
    StartPeakTime:req.body.StartPeakTime,
    EndPeakTime:req.body.EndPeakTime
  },function(err,docs){
    if (err)
    {
      throw err;
    }else{
      res.json({
        success:true,
        message:'Record Updated'
    });
    }
  });
});


module.exports = router;
