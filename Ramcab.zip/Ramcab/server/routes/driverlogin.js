var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var Driver = require('../models/driverdetailmodels');
var bcrypt=require('bcrypt-nodejs');
var jwt = require('jsonwebtoken');

router.post('/driverlogin',function(req,res){
  Driver.findOne({Emailaddress:req.body.Emailaddress},function(err,driver){
    if(err){
      throw err;
    } else if(!driver){
      res.json({success:false,message:'Sorry ! Wrong Emailaddress'});
      console.log('Emailaddress Not Found');
    } else if(!bcrypt.compareSync(req.body.Password, driver.Password)){
      res.json({success: false, message: 'Sorry ! Wrong Password'});
      console.log('Password Incorrect ');
    }else if(driver) {
        var token=jwt.sign(driver.toObject(),'thisismysecret',{
          expiresIn: 1400
        });
        res.json({
                success: true,
                jwttoken: token,
                isLoggedIn: true,
                driverdetail: driver
            });
        console.log(token);
        console.log('Toke Created');

    }
  });
});
router.post('/signup', function(req, res) {
    var newDriver = new Driver();
   newDriver.FirstName = req.body.FirstName;
   newDriver.LastName = req.body.LastName;
   newdriver.Address = req.body.Address;
   newdriver.Contactno = req.body.Contactno;
   newdriver.Emailaddress = req.body.Emailaddress;
   newdriver.Password = bcrypt.hashSync(req.body.Password);
   newdriver.Licenseno = req.body.Licenseno;
   newdriver.Cabtype = req.body.Cabtype;
   newdriver.Carno = req.body.Carno;
   newdriver.Usertype = 'Driver';
    newdriver.save(function(err,doc) {
        if (err) {
console.log(err);
          throw err;
          //  res.json(err);
        } else {
            res.json({
                success: true,
                message:'Record Saved'
            });
            console.log('Signup API Called');
        }
    });
});

module.exports = router;
