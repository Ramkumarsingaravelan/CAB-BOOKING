var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var Admin = require('../models/admindetail');
var bcrypt=require('bcrypt-nodejs');
var jwt = require('jsonwebtoken');
router.post('/adminlogin',function(req,res){
  Admin.findOne({Emailaddress:req.body.Emailaddress},function(err,admin){
    if(err){
      throw err;
    } else if(!admin){
      res.json({success:false,message:'Sorry ! Wrong Emailaddress'});
      console.log('Emailaddress Not Found');
    } else if(!bcrypt.compareSync(req.body.Password, admin.Password)){
      res.json({success: false, message: 'Sorry ! Wrong Password'});
      console.log('Password Incorrect ');
    }else if(admin) {
        var token=jwt.sign(admin.toObject(),'thisismysecret',{
          expiresIn: 1400
        });
        res.json({
                success: true,
                jwttoken: token,
                isLoggedIn: true,
                admindetail: admin
            });
        console.log(token);
        console.log('Toke Created');

    }
  });
});
router.post('/adminsignup', function(req, res) {
    var newAdmin = new Admin();
   newAdmin.FirstName = req.body.FirstName;
   newAdmin.Emailaddress = req.body.Emailaddress;
   newAdmin.Password = bcrypt.hashSync(req.body.Password);
   newAdmin.Usertype = 'Admin';
    newAdmin.save(function(err,doc) {
        if (err) {
console.log(err);
          throw err;
          //  res.json(err);
        } else {
            res.json({
                success: true,
                message:'Record Saved'
            });
            console.log('Signup API Called');
        }
    });
});

module.exports = router;
