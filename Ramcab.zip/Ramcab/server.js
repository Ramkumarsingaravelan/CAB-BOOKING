var express = require('express');
var logger = require('morgan');
var mongoose = require('mongoose');
var path = require('path');
var cabType = require('./server/routes/cabtype');
var driverDetail = require('./server/routes/driverdetail');
var driverLogin = require('./server/routes/driverlogin');
var AdminLogin = require('./server/routes/adminlogin');
var user = require('./server/routes/user');
var book = require('./server/routes/booking');
var bodyParser=require('body-parser');
var app = express();
var server = require('http').createServer(app);
var io = require('socket.io')(server);
app.use(bodyParser.json());
mongoose.connect('mongodb://localhost/myApp');
app.use(logger('dev'));
app.use('/', express.static(path.join(__dirname, './client')));
app.use('/', cabType);
app.use('/', driverDetail);
app.use('/', user);
app.use('/', driverLogin);
app.use('/', AdminLogin);
app.use('/', book);
driverList=[];

var db = mongoose.connection;
db.on('open', function() {
    console.log('App is connected to database');
});

db.on('error', function(err) {
    console.log(err);
});
io.on('connection',function(socket){
  console.log('Socket Connected' +  socket.id);

socket.on('customerdetail',function(data){
  console.log("reached customer details");


 var customer = {
userid:data.id,
lat:data.userlatitude,
long:data.userlongitude,
Name:data.FirstName,
contact:data.Contactno,
idNo:socket.id


 };
 console.log(customer);

socket.broadcast.emit('customerdetail',data);
});

socket.on('drivermessage',function(data){
  console.log("reached driver details");
  //console.log(data);

  var driver={
    did:data.id,
  lat:data.latitude,
  long:data.longitude,
  dname:data.FirstName,
  dcontact:data.Contactno,
  dcarno:data.Carno,
  dcab:data.cabtype,
  demail:data.Emailaddress,
  idNo:socket.id

};

console.log(driver);
  socket.broadcast.emit('drivermessage',data);
  //socket.broadcast.emit('driver',{driverList:driver[socket.id]});
});

socket.on("bookingConfirmToDriver",function(data){
  console.log(data);
  socket.broadcast.emit(data.driver_id,data);
});

socket.on('selectedDriver',function(data){
  console.log("selectedDriver reached");
  var selectedDriver={
    dname:data.Name,
  //dplocation:data.PickupLocation,
  //ddeslocation:data.DestinationLocation,
  contact:data.contactno,
  carno:data.vechicleinfo,
  amt:data.Amount
};
console.log(selectedDriver);
socket.broadcast.emit('selectedDriver',data);
});

});
server.listen(3000,function(req,res){
  console.log('server is running on port 3000....');
})
